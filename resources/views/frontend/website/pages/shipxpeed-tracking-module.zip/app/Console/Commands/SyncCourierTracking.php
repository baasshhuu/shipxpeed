<?php

namespace App\Console\Commands;

use App\Models\Order;
use App\Services\Tracking\ShipmentTracker;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

/**
 * Refreshes shipping_status for open shipments of every courier that has a
 * tracking API (XpressBees, Shadowfax, DTDC, ParcelX, Shiprocket).
 * Delhivery, Boxd and Tekipost keep being updated by track:delhivery.
 *
 *   php artisan track:sync                 all open shipments
 *   php artisan track:sync --awb=123456    one AWB (prints the result)
 *   php artisan track:sync --courier=dtdc  one courier
 */
class SyncCourierTracking extends Command
{
    protected $signature = 'track:sync {--awb=} {--courier=} {--limit=300}';
    protected $description = 'Update shipment statuses from courier tracking APIs';

    /** Tracker keys this command is responsible for */
    protected array $couriers = ['xpressbees', 'shadowfax', 'dtdc', 'parcelx', 'shiprocket'];

    public function handle(ShipmentTracker $tracker): int
    {
        $courierIds = collect(ShipmentTracker::COURIER_MAP)
            ->filter(fn ($key) => in_array($key, $this->option('courier') ? [$this->option('courier')] : $this->couriers, true))
            ->keys()
            ->all();

        $query = Order::query()
            ->whereNotNull('awb_number')
            ->where('awb_number', '!=', '')
            ->where(function ($q) {
                $q->whereNull('order_status')->orWhere('order_status', '!=', 'cancelled');
            });

        if ($awb = $this->option('awb')) {
            $query->where('awb_number', $awb);
        } else {
            $query->where(function ($q) use ($courierIds) {
                    foreach ($courierIds as $id) {
                        $q->orWhereRaw('LOWER(courier_id) = ?', [$id]);
                    }
                })
                ->where(function ($q) {
                    $q->whereNull('shipping_status')
                      ->orWhereNotIn('shipping_status', ShipmentTracker::FINAL_STATUSES);
                })
                ->where('updated_at', '>=', now()->subDays(60))
                ->orderBy('updated_at')
                ->limit((int) $this->option('limit'));
        }

        $orders = $query->get();
        $updated = 0;
        $failed = 0;

        foreach ($orders as $order) {
            $r = $tracker->track($order);

            if (!$r['ok'] || $r['status'] === '') {
                $failed++;
                if ($this->option('awb')) {
                    $this->warn("{$order->awb_number}: {$r['error']}");
                }
                continue;
            }

            if ($this->option('awb')) {
                $this->info("{$order->awb_number} [{$r['courier']}] {$r['raw_status']} → {$r['status']}");
                foreach (array_slice($r['events'], 0, 10) as $e) {
                    $this->line("  {$e['time']}  {$e['status']}  {$e['location']}");
                }
            }

            $new = $r['status'];
            // Unknown courier text: keep the current status rather than store free text
            if (!array_key_exists($new, ShipmentTracker::STATUS_LABELS) && $new !== 'courier Assigned') {
                continue;
            }

            if (strtolower((string) $order->shipping_status) !== strtolower($new)) {
                $order->shipping_status = $new;
                if (in_array($new, ['delivered', 'rto delivered'], true) && empty($order->delivered_date)) {
                    $order->delivered_date = now()->format('Y-m-d');
                }
                $order->save();
                $updated++;
            } else {
                $order->touch(); // move to the back of the queue
            }

            usleep(150000); // stay well under courier rate limits
        }

        $msg = "track:sync checked {$orders->count()} shipments, updated {$updated}, failed {$failed}";
        Log::info('[Tracking] ' . $msg);
        $this->info($msg);

        return self::SUCCESS;
    }
}
