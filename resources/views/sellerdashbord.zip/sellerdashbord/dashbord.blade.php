@extends('layouts.sellerdash')

@section('content')
	<div class="row">
        <!-- [ sample-page ] start -->
        <div class="col-md-6 col-xl-2">
          <div class="card text-center dashboard-card">
            <div class="icon bg-primary text-white">
              <i class="ti ti-shopping-cart"></i>
            </div>
            <h6 class="text-muted text-nowrap">New Orders</h6>
            <h4 class="fw-bold">5,240</h4>
          </div>
        </div>
      
        <div class="col-md-6 col-xl-2">
          <div class="card text-center dashboard-card">
            <div class="icon bg-info text-white">
              <i class="ti ti-truck"></i>
            </div>
            <h6 class="text-muted text-nowrap">Courier Assigned</h6>
            <h4 class="fw-bold">4,320</h4>
          </div>
        </div>
      
        <div class="col-md-6 col-xl-2">
          <div class="card text-center dashboard-card">
            <div class="icon bg-warning text-white">
              <i class="ti ti-calendar"></i>
            </div>
            <h6 class="text-muted text-nowrap">Scheduled</h6>
            <h4 class="fw-bold">2,180</h4>
          </div>
        </div>
      
        <div class="col-md-6 col-xl-2">
          <div class="card text-center dashboard-card">
            <div class="icon bg-success text-white">
              <i class="ti ti-list"></i>
            </div>
            <h6 class="text-muted text-nowrap">All Orders</h6>
            <h4 class="fw-bold">12,540</h4>
          </div>
        </div>
      
        <div class="col-md-6 col-xl-2">
          <div class="card text-center dashboard-card">
            <div class="icon bg-danger text-white">
              <i class="ti ti-refresh"></i>
            </div>
            <h6 class="text-muted text-nowrap">Customer Returns</h6>
            <h4 class="fw-bold">620</h4>
          </div>
        </div>
      
        <div class="col-md-6 col-xl-2">
          <div class="card text-center dashboard-card">
            <div class="icon bg-dark text-white">
              <i class="ti ti-package"></i>
            </div>
            <h6 class="text-muted text-nowrap">RTO</h6>
            <h4 class="fw-bold">480</h4>
          </div>
        </div>
        

        <div class="col-md-12 col-xl-6">
          <div class="d-flex align-items-center justify-content-between mb-3">
            <h5 class="mb-0">Wallet Transaction</h5>
            <ul class="nav nav-pills justify-content-end mb-0" id="chart-tab-tab" role="tablist"></ul>
          </div>
          <div class="card tbl-card">
            <div class="card-body">
              <div class="table-responsive">
                <div class="no-data">No Data Found</div>
              </div>
            </div>
          </div>
        </div>
      
        <!-- Shipment -->
        <div class="col-md-12 col-xl-6">
          <h5 class="mb-3">Shipment</h5>
          <div class="card tbl-card">
            <div class="card-body">
              <div class="table-responsive">
               
              </div>
              <!-- Shipment Status Section -->
              <div class="shipment-status">
                <span class="badge badge-delivered">Delivered</span>
                <span class="badge badge-rto">RTO</span>
                <span class="badge badge-ndr">NDR</span>
              </div>
            </div>
          </div>
        </div>
        

        <div class="col-md-12 col-xl-12">
          <h5 class="mb-3">Recent Orders</h5>
          <div class="card tbl-card">
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-hover table-borderless mb-0">
                  <thead>
                    <tr>
                      <th>TRACKING NO.</th>
                      <th>PRODUCT NAME</th>
                      <th>TOTAL ORDER</th>
                      <th>STATUS</th>
                      <th class="text-end">TOTAL AMOUNT</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><a href="#" class="text-muted">84564564</a></td>
                      <td>Camera Lens</td>
                      <td>40</td>
                      <td><span class="d-flex align-items-center gap-2"><i
                            class="fas fa-circle text-danger f-10 m-r-5"></i>Rejected</span>
                      </td>
                      <td class="text-end">$40,570</td>
                    </tr>
                    <tr>
                      <td><a href="#" class="text-muted">84564564</a></td>
                      <td>Laptop</td>
                      <td>300</td>
                      <td><span class="d-flex align-items-center gap-2"><i
                            class="fas fa-circle text-warning f-10 m-r-5"></i>Pending</span>
                      </td>
                      <td class="text-end">$180,139</td>
                    </tr>
                    <tr>
                      <td><a href="#" class="text-muted">84564564</a></td>
                      <td>Mobile</td>
                      <td>355</td>
                      <td><span class="d-flex align-items-center gap-2"><i
                            class="fas fa-circle text-success f-10 m-r-5"></i>Approved</span></td>
                      <td class="text-end">$180,139</td>
                    </tr>
                    <tr>
                      <td><a href="#" class="text-muted">84564564</a></td>
                      <td>Camera Lens</td>
                      <td>40</td>
                      <td><span class="d-flex align-items-center gap-2"><i
                            class="fas fa-circle text-danger f-10 m-r-5"></i>Rejected</span>
                      </td>
                      <td class="text-end">$40,570</td>
                    </tr>
                    <tr>
                      <td><a href="#" class="text-muted">84564564</a></td>
                      <td>Laptop</td>
                      <td>300</td>
                      <td><span class="d-flex align-items-center gap-2"><i
                            class="fas fa-circle text-warning f-10 m-r-5"></i>Pending</span>
                      </td>
                      <td class="text-end">$180,139</td>
                    </tr>
                    <tr>
                      <td><a href="#" class="text-muted">84564564</a></td>
                      <td>Mobile</td>
                      <td>355</td>
                      <td><span class="d-flex align-items-center gap-2"><i
                            class="fas fa-circle text-success f-10 m-r-5"></i>Approved</span></td>
                      <td class="text-end">$180,139</td>
                    </tr>
                    <tr>
                      <td><a href="#" class="text-muted">84564564</a></td>
                      <td>Camera Lens</td>
                      <td>40</td>
                      <td><span class="d-flex align-items-center gap-2"><i
                            class="fas fa-circle text-danger f-10 m-r-5"></i>Rejected</span>
                      </td>
                      <td class="text-end">$40,570</td>
                    </tr>
                    <tr>
                      <td><a href="#" class="text-muted">84564564</a></td>
                      <td>Laptop</td>
                      <td>300</td>
                      <td><span class="d-flex align-items-center gap-2"><i
                            class="fas fa-circle text-warning f-10 m-r-5"></i>Pending</span>
                      </td>
                      <td class="text-end">$180,139</td>
                    </tr>
                    <tr>
                      <td><a href="#" class="text-muted">84564564</a></td>
                      <td>Mobile</td>
                      <td>355</td>
                      <td><span class="d-flex align-items-center gap-2"><i
                            class="fas fa-circle text-success f-10 m-r-5"></i>Approved</span></td>
                      <td class="text-end">$180,139</td>
                    </tr>
                    <tr>
                      <td><a href="#" class="text-muted">84564564</a></td>
                      <td>Mobile</td>
                      <td>355</td>
                      <td><span class="d-flex align-items-center gap-2"><i
                            class="fas fa-circle text-success f-10 m-r-5"></i>Approved</span></td>
                      <td class="text-end">$180,139</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      

    </div>
@endsection